<?php
/**
 * @package     Joomla.Site
 * @subpackage  Templates.protostar
 *
 * @copyright   Copyright (C) 2005 - 2018 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

/** @var JDocumentHtml $this */

$app  = JFactory::getApplication();
$user = JFactory::getUser();

// Output as HTML5
$this->setHtml5(true);

// Getting params from template
$params = $app->getTemplate(true)->params;

// Detecting Active Variables
$option   = $app->input->getCmd('option', '');
$view     = $app->input->getCmd('view', '');
$layout   = $app->input->getCmd('layout', '');
$task     = $app->input->getCmd('task', '');
$itemid   = $app->input->getCmd('Itemid', '');
$sitename = htmlspecialchars($app->get('sitename'), ENT_QUOTES, 'UTF-8');

if ($task === 'edit' || $layout === 'form')
{
	$fullWidth = 1;
}
else
{
	$fullWidth = 0;
}

// Add JavaScript Frameworks
JHtml::_('bootstrap.framework');

// Add template js
JHtml::_('script', 'template.js', array('version' => 'auto', 'relative' => true));

// Add html5 shiv
JHtml::_('script', 'jui/html5.js', array('version' => 'auto', 'relative' => true, 'conditional' => 'lt IE 9'));

// Add Stylesheets
JHtml::_('stylesheet', 'template.css', array('version' => 'auto', 'relative' => true));

// Use of Google Font
if ($this->params->get('googleFont'))
{
	JHtml::_('stylesheet', 'https://fonts.googleapis.com/css?family=' . $this->params->get('googleFontName'));
	$this->addStyleDeclaration("
	h1, h2, h3, h4, h5, h6, .site-title {
		font-family: '" . str_replace('+', ' ', $this->params->get('googleFontName')) . "', sans-serif;
	}");
}

// Template color
if ($this->params->get('templateColor'))
{
	$this->addStyleDeclaration('
	body.site {
		border-top: 3px solid ' . $this->params->get('templateColor') . ';
		background-color: ' . $this->params->get('templateBackgroundColor') . ';
	}
	a {
		color: ' . $this->params->get('templateColor') . ';
	}
	.nav-list > .active > a,
	.nav-list > .active > a:hover,
	.dropdown-menu li > a:hover,
	.dropdown-menu .active > a,
	.dropdown-menu .active > a:hover,
	.nav-pills > .active > a,
	.nav-pills > .active > a:hover,
	.btn-primary {
		background: ' . $this->params->get('templateColor') . ';
	}');
}

// Check for a custom CSS file
JHtml::_('stylesheet', 'user.css', array('version' => 'auto', 'relative' => true));

// Check for a custom js file
JHtml::_('script', 'user.js', array('version' => 'auto', 'relative' => true));

// Load optional RTL Bootstrap CSS
JHtml::_('bootstrap.loadCss', false, $this->direction);

// Adjusting content width
$position7ModuleCount = $this->countModules('position-7');
$position8ModuleCount = $this->countModules('position-8');

if ($position7ModuleCount && $position8ModuleCount)
{
	$span = 'span6';
}
elseif ($position7ModuleCount && !$position8ModuleCount)
{
	$span = 'span9';
}
elseif (!$position7ModuleCount && $position8ModuleCount)
{
	$span = 'span9';
}
else
{
	$span = 'span12';
}

// Logo file or site title param
if ($this->params->get('logoFile'))
{
	$logo = '<img src="' . JUri::root() . $this->params->get('logoFile') . '" alt="' . $sitename . '" />';
}
elseif ($this->params->get('sitetitle'))
{
	$logo = '<span class="site-title" title="' . $sitename . '">' . htmlspecialchars($this->params->get('sitetitle'), ENT_COMPAT, 'UTF-8') . '</span>';
}
else
{
	$logo = '<span class="site-title" title="' . $sitename . '">' . $sitename . '</span>';
}

// Add Stylesheets
//JHtml::_('stylesheet', 'bootstrap.min.css', array('version' => 'auto', 'relative' => true));
// Add Stylesheets
//JHtml::_('stylesheet', 'style.css', array('version' => 'auto', 'relative' => true));

?>
<!DOCTYPE html>
<html lang="<?php echo $this->language; ?>" dir="<?php echo $this->direction; ?>">
<head>
<link rel="icon" href="/templates/protostar/cropped-fav.png" sizes="192x192" />

<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<jdoc:include type="head" />

	<link rel="stylesheet" href="templates/protostar/css/bootstrap.min.css">
	
	<!-- Theme CSS -->
	<link rel="stylesheet" href="templates/protostar/css/style.css">

    <!-- <script src="templates/protostar/js/bootstrap.min.js"></script>-->

</head>
<body class="site <?php echo $option
	. ' view-' . $view
	. ($layout ? ' layout-' . $layout : ' no-layout')
	. ($task ? ' task-' . $task : ' no-task')
	. ($itemid ? ' itemid-' . $itemid : '')
	. ($params->get('fluidContainer') ? ' fluid' : '')
	. ($this->direction === 'rtl' ? ' rtl' : '');
?>">

	<div class="body" id="top">

			<!-- Header -->
			<header>
				<div class="top_header">
		  			<div class="container">
			  			<div class="row">
			  				<div class="col-sm-6 hidden-xs">
				  				<div class="social_icons">
				  					<ul>
				  						<li>
				  							<a href="#"><i class="fa fa-facebook"></i></a>
				  						</li>
				  						<li>
				  							<a href="#"><i class="fa fa-twitter"></i></a>
				  						</li>
				  						<li>
				  							<a href="#"><i class="fa fa-google-plus"></i></a>
				  						</li>
				  						<li>
				  							<a href="#"><i class="fa fa-instagram"></i></a>
				  						</li>
				  					</ul>
				  				</div>
			  				</div>
			  				<div class="col-sm-6 text-right">
			  					<jdoc:include type="modules" name="position-0" style="none" />
			  				</div>
			  			</div>
		  			</div>
	  			</div>
				<nav class="navbar theme_nav sticky">
				  <div class="container">
				  <div class="row">
				  	<div class="col-md-4">
						<div class="navbar-header">
						  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#theme_nav" aria-expanded="false">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						  </button>
						  <a href="<?php //echo $this->baseurl; ?>https://gomeliex.com">
							<?php echo $logo; ?>
							<?php if ($this->params->get('sitedescription')) : ?>
								<?php echo '<div class="site-description">' . htmlspecialchars($this->params->get('sitedescription'), ENT_COMPAT, 'UTF-8') . '</div>'; ?>
							<?php endif; ?>
						  </a>
						</div>
					</div>
					<div class="col-md-8">
						<div class="collapse navbar-collapse navbar-right" id="theme_nav">
							<jdoc:include type="modules" name="banner" style="xhtml" />
						</div>
					</div>
				  </div>
				  </div>
				</nav>
					<!-- Header site issue marque start -->
				<!--	<div class="row alert-marq">		
                <div class="container cls-marq">
                <marquee width="100%" direction="left" onMouseOver="this.stop()" onMouseOut="this.start()">
                <span class="blink">Note:</span>Sorry for the issue which was caused. We found the cause of the issue. The file size is bigger than 75 KB (for attachments) Then we are facing this problem. The Server is not allowing us to upload the images more than 75KB. System is working fine with attachments uploading less than 75KB or Without attachments. We are working with the server vendor to resolve this issue on top priority.
                </marquee>
                </div>
                </div>-->
                	<!-- Header site issue marque end -->
			</header>
			<!-- Header -->

			<!-- <div class="<?php echo ($params->get('fluidContainer') ? '-fluid' : ''); ?>">
				<?php if ($this->countModules('position-1')) : ?>
					<jdoc:include type="modules" name="position-1" style="none" />
				<?php endif; ?>
			</div> -->

			<!-- Page Content -->
			<section class="page_content">
				<?php if ($position8ModuleCount) : ?>
					<!-- Begin Sidebar -->
					<div id="sidebar" class="span3">
						<div class="sidebar-nav">
							<jdoc:include type="modules" name="position-8" style="xhtml" />
						</div>
					</div>
					<!-- End Sidebar -->
				<?php endif; ?>
				<main id="content" role="main">

					<!-- Begin Content -->
					<jdoc:include type="modules" name="position-3" style="xhtml" />
					<div class="theme_alert">
						<div class="container">
							<jdoc:include type="message" />
						</div>
					</div>
					<jdoc:include type="component" />
					<jdoc:include type="modules" name="position-2" style="none" />
					<!-- End Content -->
					
				</main>
				<?php if ($position7ModuleCount) : ?>
					<div id="aside" class="span3">
						<!-- Begin Right Sidebar -->
						<jdoc:include type="modules" name="position-7" style="well" />
						<!-- End Right Sidebar -->
					</div>
				<?php endif; ?>
			</section>
			<!-- Page Content -->

			<!-- Footer -->
			<footer class="footer" role="contentinfo">
				<jdoc:include type="modules" name="footer" style="none" />
				<!-- Footer Top Content Start -->
				<div class="custom">
    <div class="container footer_top">
      <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 pad-tb rgt-sec1 brd-line">
          <div class="col-lg-8 col-md-8 col-sm-10 col-xs-12 cls-fmenu">
            <ul>
              <li><a href="https://gomeliex.com/">Home</a></li>
              <li><a href="https://gomeliex.com/service-fees/">Service Fees</a></li>
              <li><a href="https://gomeliex.com/contact-us/">Contact us</a></li>
              <li><a href="https://gomeliex.com/international-shipping-restrictions/">International Shipping Restrictions</a></li>
            </ul>
          </div>
          <div class="col-lg-4 col-md-4 col-sm-2 col-xs-12 cls-fmenu text-right">
            <ul>
              <li><a href="#"><i class="fa fa-facebook"></i></a></li>
            </ul>
          </div>
        </div>
        <div class="col-lg-12 col-md-12 col-sm-12 pad-tb rgt-sec1">
          <div class="col-lg-6 col-md-5 col-sm-6 col-xs-12">
            <div class="fimg-blk"><img src="/images/logo.png" alt="meliexdevfe.boxonlogistics.com"></div>
            <ul>
              <li>6325 N Orange Blossom Trl,<br>Ste 132,<br>
                Orlando Florida 32810</li>
              <li> <a target="_blank" href="https://www.google.com/maps/dir//3772+Silver+Star+Rd,+Orlando,+FL+32808/@28.344603,-81.7941843,10z/data=!4m8!4m7!1m0!1m5!1m1!1s0x88e77a02a05466c3:0x5cc2c467337ea811!2m2!1d-81.4280131!2d28.5769723" class="btn-getdir">
              <span class="text">Get directions</span></a> </li>
            </ul>
          </div>
          <div class="col-lg-6 col-md-7 col-sm-6 col-xs-12">
            <h2>Subscribe <span class="cls-dash"></span></h2>
            <div class="cls-subscribe-txt">
              <p>Don’t miss the latest deals from the top us brands and major retailers. Subscribe to our newsletter channel and be informed.</p>
            </div>
            <div class="cls-subscribe">
              <form action="https://egadgetsales.us14.list-manage.com/subscribe/post?u=1604c6a20889d977c335dce1d&id=9c534e7040" method="post" class="subs-form" target="_blank">
                <input type="text" class="cls-email">
                <input type="submit" value="Subscribe">
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
				<!-- Footer Top Content End -->
				<div class="container-fluid btm-bg">
    <div class="container footer_bottom">
      <div class="row">
        <div class="col-lg-5 col-md-5 col-sm-5 col-xs-12"><a href="https://gomeliex.com/">© 2020 GoMeliex.com</a></div>
        <div class="col-lg-7 col-md-7 col-sm-7 col-xs-12 text-right"><span>International Freight Forwarding Services</span></div>
      </div>
    </div>
  </div>
				<!-- <a class="" href="#top" id="back-top"> <?php echo JText::_('TPL_PROTOSTAR_BACKTOTOP'); ?> </a> -->
			</footer>
			<!-- Footer -->
	</div>

	<jdoc:include type="modules" name="debug" style="none" />
<!-- <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>-->
<script type="text/javascript">
    // sticky header
    /* $(window).scroll(function(){
      var sticky = $('.sticky'),
          scroll = $(window).scrollTop();

      if (scroll >= 100) sticky.addClass('fixed');
      else sticky.removeClass('fixed');
    });*/
    jQuery(document).ready(function() {
      setTimeout(function() {
        jQuery('.alert-info').slideUp("slow");
    }, 3600);
    var pf="<?php echo $_GET['id'];?>";
    if(pf==8){
        console.log('hi')
        jQuery('.page_content').css('background-image','none'); 
    }
  }); 
    jQuery('.navbar-toggle').click(function(){
      jQuery('#theme_nav').css('height', 'auto');
      jQuery('.custommenu').toggle('collapse');
	  jQuery('.moduletable_menu').toggle(); 
    });

</script> 

</body>
</html>